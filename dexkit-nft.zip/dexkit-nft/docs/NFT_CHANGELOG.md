CHANGELOG

## v0.1.2 - _September 28, 2021_

    * Fixes in plugin logic

## v0.1.1 - _July 14, 2021_

    * Improve plugin logic
    * Marketplace menu improvements

## v0.1.0 - _June 18, 2021_

    * Init