=== DexKit Aggregator ===
Contributors: dexkit
Tags: crypto,eth,bsc,polygon,stable
Requires at least: 5.0.0
Tested up to: 5.6.0
Requires PHP: 7.0.0
License: GPL

Easily insert crypto aggregator in your website that searchs for over 40 DEX's on Ethereum, Polygon and Binance Smart Chain




== Changelog == 

= 0.0.1 =
* init
