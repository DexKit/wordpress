# How to generate shortcode used by plugin?

You have two ways: Follow documentation or use our wizard

# Shortcode attributes not working?

If you are facing this issue, and you confirmed that attributes are well filled, please try the follow options:

- Open the page where shortcode plugin is on incognito mode on the browser, this will load the plugin without cache
- Clear cache on browser
- Check Wordpress permissions to access files from plugins
- We use hardcoded paths for wp-content and plugin name, if you are using a custom setup for wp-content or use subdirectories the plugin may not work.

If anything works please check console on Chrome and saw the response of it and contact DexKit support at [Discord Support](https://discord.gg/kjp4m6PAUA)
