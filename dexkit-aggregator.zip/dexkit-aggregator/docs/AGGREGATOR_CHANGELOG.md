CHANGELOG

## v0.1.8 - _January 16, 2021_

    * Added Finnish translation and optional shortcode

## v0.1.7 - _January 7, 2021_

    * Second fix issue on affiliate address fees distribution

## v0.1.6 - _January 7, 2021_

    * Fixed issue on affiliate address fees distribution

## v0.1.5 - _November 8, 2021_

    * Fixed issue on mobile

## v0.1.4 - _October 17, 2021_

    * Added Avalanche network, added affiliate


## v0.1.3 - _September 28, 2021_

    * Fixes in plugin logic

## v0.1.2 - _September 2, 2021_

    * Fixes in plugin logic

## v0.1.1 - _August 2, 2021_

    * Added Limit Orders support on ETH network



## v0.1.0 - _July 15, 2021_

    * Init