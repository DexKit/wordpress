# DexKit Aggregator Plugin

## Current Plugin Version: 0.1.3 ##


DexKit offers whitelabel functionality being the current available:

 - NFT Marketplace
 - Aggregator

# How to install Aggregator plugin at Wordpress

- Download [Plugin](../dexkit-aggregator.zip)

- Follow the [GUIDE](docs/INSTALL_AGGREGATOR.md)


# Found a BUG or want a FEATURE that not exists ?

- Please open an issue on this [repository](https://github.com/DexKit/wordpress)







# Changelog

[Aggregator Changelog](docs/AGGREGATOR_CHANGELOG.md)